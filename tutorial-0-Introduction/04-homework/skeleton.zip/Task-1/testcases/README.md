# Test Cases

Each subfolder is one automated test. Run the suite from the repository root:

```text
powershell -ExecutionPolicy Bypass -File .\run_tests.ps1 -Task 1 # Windows
bash ./run_tests.sh 1                                           # macOS / Linux
```

The runner rebuilds `Task1` first, so tests always exercise the current code.
Part B (`testcaseB*`) cases are skipped unless you add `-Bonus` (PowerShell) or `-b` (bash).

## What each test contains

| File | Purpose |
| ------ | --------- |
| `input.txt` | The exact stdin script fed to the program (menu choice, values, matrices — one per line). |
| `output.txt` | The **exact expected output** for that `input.txt`. Each non-blank line is a required substring; a leading `!` means the substring must **not** appear, and a leading `#` is a comment. |

## The test cases

| Test | What it checks |
| ------ | ---------------- |
| `testcase1-3` | `rolling_average`. |
| `testcase4-5` | `kalman_init` + `kalman_step` |
| `testcase6-8` | `convolve` |
| `testcaseB1-3` | `gaussian_filter` (bonus) |
| `testcaseB4-5` | `median_filter` (bonus) |

## Adding a new test

1. Create a new folder under `testcases/`, named `testcase<number>` (or `testcaseB<number>` for a Part B test) — for example `testcases/testcase9/`.
2. Add `input.txt` (the exact stdin script).
