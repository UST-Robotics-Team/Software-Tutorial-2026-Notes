# Test Cases

Each subfolder is one test. Run the suite from the repository root. The runner rebuilds `Task3` and runs the fixtures in this learning order: `sort_rack`, `exchange_tiles`, `word_score`, `play_valid_word`, `anagram_finder`, then `highest_score`.

```text
powershell -ExecutionPolicy Bypass -File .\run_tests.ps1 -Task 3 # Windows
bash ./run_tests.sh 3                                           # macOS / Linux
```

Part B (`testcaseB*`) cases are skipped unless you add `-Bonus` (PowerShell) or `-b` (bash).

## What each test contains

| File | Purpose |
|------|---------|
| `state.txt` | A board state, loaded with the game's import-state menu option. |
| `input.txt` | The exact stdin script fed to the game (the setup menu choice — a state file for option `3`, or a draw order for option `4` — then `ANAG`, `HIGH`, `PLAY ...`, `QUIT`). |
| `output.txt` | The **exact expected output** for that `input.txt`. Each non-blank line is a required substring; a leading `!` means the substring must **not** appear, and a leading `#` is a comment. |

## The test cases

| Test | What it checks |
|------|----------------|
| `testcase1` | `sort_rack` |
| `testcase2, testcase3` | `exchange_tiles` |
| `testcase4-7` | `word_score` and `play_valid_word` |
| `testcaseB1-3` | `anagram_finder` (bonus) and `highest_score` (bonus) |

## Adding a new test

1. Create a new folder under `testcases/`, named `testcase<number>` (or `testcaseB<number>` for a Part B test) — for example `testcases/testcase10/`.
2. Add `state.txt` (the board position, if needed) and `input.txt` (the commands).
3. Run the game once by hand, verify the output is correct, and save it as `output.txt` (or keep only the key lines you want checked).
4. Re-run the suite — the new folder is picked up automatically.
