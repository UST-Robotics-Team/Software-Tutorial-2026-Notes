/*
 * HOW TO COMPILE (run from the Task-3 folder):
 *   gcc -Wuninitialized -std=c99 main.c Task3.c given.c lib/dict.c -o Task3
 *   (add -lm on Linux/macOS)
 *
 * given.c holds the shared "given" functions.
 */
#include "Task3.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static char g_draw_order[101];        
static int g_draw_pos = 0;            
static int g_debug_draw = 0;          
static Bag* g_debug_bag = NULL;       
static unsigned int g_rand_state = 1; 

void srand(unsigned int seed){
    g_rand_state = seed;
}

int rand(void){
    if(g_debug_draw && g_debug_bag && g_debug_bag->tiles_left > 0){
        char want = g_draw_order[g_draw_pos];
        if(want != '\0'){
            g_draw_pos++;
            for(int i=0; i<g_debug_bag->tiles_left; i++){
                if(g_debug_bag->tiles[i] == want){
                    return i;
                }
            }
        }
    }
    g_rand_state = g_rand_state * 1103515245u + 12345u;
    return (int)((g_rand_state >> 16) & 0x7fff);
}

int main(){
    Game game;
    char line[128];
    int startup_complete = 0;

    while(!startup_complete){
        printf("Select a game setup option:\n");
        printf("  1. Play the game (random seed)\n");
        printf("  2. Play the game (set seed)\n");
        printf("  3. Import game state\n");
        printf("  4. Play the game (set draw order)\n");
        printf("> ");

        if(!fgets(line, sizeof(line), stdin)){
            return 0;
        }

        int setup_option;
        if(sscanf(line, "%d", &setup_option)!=1){
            printf("Unknown option. Choose 1, 2, 3 or 4.\n");
            continue;
        }

        if(setup_option==1){
            srand((unsigned int)time(NULL));
            init_game(&game);
            startup_complete = 1;
        }
        else if(setup_option==2){
            int seed;
            printf("Enter seed: ");
            if(!fgets(line, sizeof(line), stdin)){
                return 0;
            }
            if(sscanf(line, "%d", &seed)==1){
                srand((unsigned int)seed);
                init_game(&game);
                startup_complete = 1;
            }
            else{
                printf("Invalid seed. Enter an integer.\n");
            }
        }
        else if(setup_option==3){
            init_game(&game);
            printf("Enter state file name (e.g. example_state.txt): ");
            if(!fgets(line, sizeof(line), stdin)){
                return 0;
            }
            char fname[100];
            if(sscanf(line, "%99s", fname)==1){
                import_state(&game, fname);
                startup_complete = 1;
            }
            else{
                printf("Invalid state file name.\n");
            }
        }
        else if(setup_option==4){
            printf("Enter draw order (up to 100 tiles, A-Z and * for a blank): ");
            if(!fgets(line, sizeof(line), stdin)){
                return 0;
            }

            char order[101];
            if(sscanf(line, "%100s", order)!=1){
                printf("Invalid draw order.\n");
                continue;
            }
            int order_len = 0;
            int order_ok = 1;
            while(order[order_len]!='\0'){
                if(order[order_len]>='a' && order[order_len]<='z'){
                    order[order_len] -= 32;
                }
                if(!((order[order_len]>='A' && order[order_len]<='Z') || order[order_len]=='*')){
                    order_ok = 0;
                }
                order_len++;
            }
            if(!order_ok){
                printf("Invalid draw order: use letters A-Z and * only.\n");
                continue;
            }

            init_game(&game);
            for(int i=0;i<=order_len;i++){
                g_draw_order[i] = order[i];
            }
            for(int i=0;i<order_len;i++){
                game.bag.tiles[i] = order[i];
            }
            game.bag.tiles[order_len] = '\0';
            game.bag.tiles_left = order_len;
            for(int i=0;i<8;i++){
                game.P1.rack[i] = '\0';
                game.P2.rack[i] = '\0';
            }

            g_debug_bag = &game.bag;
            g_draw_pos = 0;
            g_debug_draw = 1;
            for(int i=0;i<7;i++){
                draw_tile(&game.bag, &game.P1);
            }
            for(int i=0;i<7;i++){
                draw_tile(&game.bag, &game.P2);
            }

            printf("Debug draw order active for %d tiles.\n", order_len);
            startup_complete = 1;
        }
        else{
            printf("Unknown option. Choose 1, 2, 3 or 4.\n");
        }
    }

    int passes = 0;
    int game_over = 0;
    int skip_display = 0;

    while(!game_over){
        Player* player = (game.turn==1) ? &game.P1 : &game.P2;

        if(!skip_display){
            print_turn(game);
            
            unseen_tiles_info(&game, player);
            sort_rack(player);
            print_rack(*player);
        }
        skip_display = 0;

        printf("Select an option:\n");
        printf("  PLAY  - play a word\n");
        printf("  EXCH  - exchange tiles\n");
        printf("  PASS  - skip your turn\n");
        printf("  ANAG  - list all words you can make from your rack\n");
        printf("  HIGH  - show the highest scoring move\n");
        printf("  QUIT  - end the game\n");
        printf("> ");

        if(!fgets(line, sizeof(line), stdin)){
            break;  // end of input
        }

        char option[16];
        if(sscanf(line, "%15s", option)!=1){
            continue;  // empty line, ask again
        }

        for(int i=0; option[i]!='\0'; i++){
            if(option[i]>='a' && option[i]<='z'){
                option[i] -= 32;
            }
        }

        if(strcmp(option, "PLAY")==0){
            printf("Enter move (WORD CELL DIR, e.g. AA H8 H): ");
            if(!fgets(line, sizeof(line), stdin)){
                break;
            }

            char word[16];
            char cell[4];
            char dir;
            if(sscanf(line, "%15s %3s %c", word, cell, &dir)==3){
                if(cell[0]>='a' && cell[0]<='z'){
                    cell[0] -= 32;
                }
                if(dir>='a' && dir<='z'){
                    dir -= 32;
                }

                int cell_ok = (cell[0]>='A' && cell[0]<='O');
                for(int i=1; cell_ok && cell[i]!='\0'; i++){
                    if(cell[i]<'0' || cell[i]>'9'){
                        cell_ok = 0;
                    }
                }

                int col = cell[0] - 'A';
                int row = atoi(cell+1) - 1;

                if(!cell_ok || row<0 || row>14){
                    printf("Invalid cell: use a column letter A-O and row 1-15 (e.g. H8).\n");
                }
                else if(play_valid_word(&game, player, word, row, col, dir)){
                    passes = 0;
                    while(tiles_left(&game.bag)>0 && rack_count(player)<7){
                        draw_tile(&game.bag, player);
                    }
                    sort_rack(player);
                    if(tiles_left(&game.bag)==0 && rack_count(player)==0){
                        game_over = 1;
                    }
                    else{
                        game.turn = (game.turn==1) ? 2 : 1;
                    }
                }
                else{
                    printf("Invalid move: not a valid word or cannot be played there.\n");
                }
            }
            else{
                printf("Invalid move format. Use WORD CELL DIR, e.g. JET H8 H.\n");
            }
        }
        else if(strcmp(option, "EXCH")==0){
            printf("Enter tiles to exchange (e.g. AE): ");
            if(!fgets(line, sizeof(line), stdin)){
                break;
            }

            char tiles[16];
            if(sscanf(line, "%15s", tiles)==1){
                for(int i=0; tiles[i]!='\0'; i++){
                    if(tiles[i]>='a' && tiles[i]<='z'){
                        tiles[i] -= 32;
                    }
                }
                if(exchange_tiles(&game, player, tiles)){
                    passes = 0;
                    game.turn = (game.turn==1) ? 2 : 1;
                }
                else{
                    if(tiles_left(&game.bag) < (int)strlen(tiles)){
                        printf("Cannot exchange: fewer than %d tiles left in the bag.\n", (int)strlen(tiles));
                    }
                    else{
                        printf("Invalid exchange: one of those tiles is not in your rack.\n");
                    }
                }
            }
            else{
                printf("Invalid exchange. Enter the tiles to exchange, e.g. AE.\n");
            }
        }
        else if(strcmp(option, "HIGH")==0){
            printf("Suggested move: %s\n", highest_score(&game, player));
            skip_display = 1;
        }
        else if(strcmp(option, "ANAG")==0){
            anagram_finder(player);
            skip_display = 1;
        }
        else if(strcmp(option, "PASS")==0){
            passes++;
            if(passes>=2){
                game_over = 1;
            }
            else{
                game.turn = (game.turn==1) ? 2 : 1;
            }
        }
        else if(strcmp(option, "QUIT")==0){
            game_over = 1;
        }
        else{
            printf("Unknown option. Choose PLAY, EXCH, PASS, QUIT, HIGH, ANAG or LOAD.\n");
        }
    }
    print_board(game);
    int p1_left = 0;
    for(int i=0; i<7 && game.P1.rack[i]!='\0'; i++){
        p1_left += value(game.P1.rack[i]);
    }
    int p2_left = 0;
    for(int i=0; i<7 && game.P2.rack[i]!='\0'; i++){
        p2_left += value(game.P2.rack[i]);
    }
    game.P2.score += 2*p1_left;
    game.P1.score += 2*p2_left;

    printf("\n================ GAME OVER ================\n");
    if(p1_left > 0){
        printf("Player 1 has %d points of tiles left, so Player 2 gains %d.\n",
               p1_left, 2*p1_left);
    }
    if(p2_left > 0){
        printf("Player 2 has %d points of tiles left, so Player 1 gains %d.\n",
               p2_left, 2*p2_left);
    }
    printf("Player 1: %d points\n", game.P1.score);
    printf("Player 2: %d points\n", game.P2.score);
    if(game.P1.score > game.P2.score){
        printf("Player 1 wins!\n");
    }
    else if(game.P2.score > game.P1.score){
        printf("Player 2 wins!\n");
    }
    else{
        printf("It's a tie!\n");
    }
    return 0;
}

