//You are NOT ALLOWED to add any other libraries
//
#include "Task3.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lib/dict.h"
//

//You are allowed to define helpers in this file to assist you in implementing the required functions. However, you are NOT allowed to modify the function signatures of the provided functions in Task3.h.

// PART A (MANDATORY)

void sort_rack(Player* player){
    //Task 3A(i)
}

int exchange_tiles(Game* game, Player* player, const char* tiles){
    //Task 3A(ii)
    return 0;
}

int word_score(Game* game, const char* word, int row, int col, char direction){
    //Task 3A(iii)
    return 0;
}

int play_valid_word(Game* game, Player* player, const char* word, int row, int col, char direction){
    //Task 3A(iv)
    return 0;
}

//PART B (OPTIONAL)
//Please note that the following functions are optional. However, you may choose to implement them for your own learning and practice.

void anagram_finder(Player* player) {
    //Task 3B(i)
}

char* highest_score(Game* game, Player* player) {
    //TODO 3B(ii)
    return "PASS";
}
