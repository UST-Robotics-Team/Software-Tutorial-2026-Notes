#!/usr/bin/env bash

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

if ! command -v gcc >/dev/null 2>&1; then
    echo "gcc was not found on PATH." >&2
    exit 1
fi

task_config() {
    case "$1" in
        1) TASK_DIR="Task-1"; TASK_SOURCES="main.c Task1.c" ;;
        2) TASK_DIR="Task-2"; TASK_SOURCES="main.c Task2.c" ;;
        3) TASK_DIR="Task-3"; TASK_SOURCES="main.c Task3.c given.c lib/dict.c" ;;
        *) return 1 ;;
    esac
    return 0
}

trim() {
    local s="$1"
    s="${s#"${s%%[![:space:]]*}"}"
    s="${s%"${s##*[![:space:]]}"}"
    printf '%s' "$s"
}

#Due to Task 3 using C rand(), some outputs differ between versions of libc. These outputs are ignored in grading.
is_runtime_dependent() {
    local task="$1" line="$2"
    [[ "$task" == "3" ]] || return 1
    [[ "$line" == Unseen\ tiles\ for\ player:* ||
       "$line" == Current\ rack:* ||
       "$line" == Player\ [12]\ has\ *\ points\ of\ tiles\ left,* ||
       "$line" =~ ^Player\ [12]:\ [0-9]+\ points$ ]]
}

run_task_tests() {
    local task="$1"
    local testsDir="testcases"
    local passed=0 failed=0 skipped=0 bonus_skipped=0 dumped=0

    shopt -s nullglob
    local entries=() path case_name
    for path in "$testsDir"/*/; do
        case_name=$(basename "$path")
        if [[ "$case_name" =~ ^testcaseB([0-9]+)$ ]]; then
            entries+=("1 ${BASH_REMATCH[1]} $case_name")
        elif [[ "$case_name" =~ ^testcase([0-9]+)$ ]]; then
            entries+=("0 ${BASH_REMATCH[1]} $case_name")
        fi
    done

    if [[ ${#entries[@]} -eq 0 ]]; then
        echo "No test cases found in $testsDir/" >&2
        return 1
    fi

    local sorted
    mapfile -t sorted < <(printf '%s\n' "${entries[@]}" | sort -k1,1n -k2,2n | cut -d' ' -f3)

    if [[ -n "$DUMP_DIR" ]]; then
        rm -rf "$DUMP_DIR"
        mkdir -p "$DUMP_DIR"
    fi

    local name dir inputFile outputFile actual
    for name in "${sorted[@]}"; do
        if [[ "$name" == testcaseB* && $GRADE_BONUS -eq 0 ]]; then
            echo "[SKIP] $name (bonus; pass -b to grade)"
            bonus_skipped=$((bonus_skipped + 1))
            continue
        fi

        dir="$testsDir/$name/"
        inputFile="$dir/input.txt"
        outputFile="$dir/output.txt"

        if [[ ! -f "$inputFile" || ! -f "$outputFile" ]]; then
            echo "[SKIP] $name (missing input.txt or output.txt)"
            skipped=$((skipped + 1))
            continue
        fi

        if [[ -n "$DUMP_DIR" ]]; then
            "./Task$task" < "$inputFile" > "$DUMP_DIR/$name.txt" 2>&1 || true
            actual=$(cat "$DUMP_DIR/$name.txt")
            dumped=$((dumped + 1))
        else
            actual=$("./Task$task" < "$inputFile" 2>&1) || true
        fi

        local ok=1 line sub
        local problems=()
        while IFS= read -r line || [[ -n "$line" ]]; do
            line=$(trim "$line")
            [[ -z "$line" ]] && continue
            [[ "$line" == \#* ]] && continue
            is_runtime_dependent "$task" "$line" && continue

            if [[ "$line" == \!* ]]; then
                sub=$(trim "${line:1}")
                [[ -z "$sub" ]] && continue
                if [[ "$actual" == *"$sub"* ]]; then
                    ok=0
                    problems+=("  must NOT contain: '$sub'")
                fi
            else
                if [[ "$actual" != *"$line"* ]]; then
                    ok=0
                    problems+=("  missing: '$line'")
                fi
            fi
        done < "$outputFile"

        if [[ $ok -eq 1 ]]; then
            echo "[PASS] $name"
            passed=$((passed + 1))
        else
            echo "[FAIL] $name"
            local p
            for p in "${problems[@]}"; do
                echo "$p"
            done
            failed=$((failed + 1))
        fi
    done

    echo ""
    echo "Passed: $passed   Failed: $failed   Skipped: $skipped"
    if [[ $bonus_skipped -gt 0 ]]; then
        echo "Bonus skipped: $bonus_skipped (Part B; pass -b to grade)"
    fi
    if [[ $dumped -gt 0 ]]; then
        echo "Output dumped to $DUMP_DIR/ ($dumped files)"
    fi
    if [[ $passed -eq 0 && $failed -eq 0 ]]; then
        echo "No test cases were graded." >&2
        return 1
    fi
    [[ $failed -eq 0 ]] || return 1
    return 0
}

run_task() {
    local task="$1"

    if ! task_config "$task"; then
        echo "Unknown task: $task" >&2
        return 1
    fi

    local folder="$TASK_DIR" sources="$TASK_SOURCES"

    echo ""
    echo "=== Task $task ($folder) ==="

    if [[ ! -d "$folder" ]]; then
        echo "Missing task folder: $folder" >&2
        return 1
    fi

    pushd "$folder" >/dev/null || return 1

    echo "Building Task$task ..."
    if ! gcc -Wuninitialized -std=c99 $sources -o Task$task -lm; then
        echo "Build failed for $folder" >&2
        popd >/dev/null
        return 1
    fi

    local status=0
    run_task_tests "$task" || status=1

    popd >/dev/null
    return $status
}

GRADE_BONUS=0
DUMP_DIR="dump"
selection=""

while [[ $# -gt 0 ]]; do
    flag=$(printf '%s' "$1" | tr '[:upper:]' '[:lower:]') # case insensitive
    case "$flag" in
        -t|--t|-task|--task)
            if [[ $# -lt 2 ]]; then
                echo "Missing value for $1 (expected 1, 2, 3 or all)." >&2
                exit 1
            fi
            selection="$2"
            shift 2
            ;;
        -b|--b|-bonus|--bonus) GRADE_BONUS=1; shift ;;
        -nodump|--nodump|--no-dump|-n|--n) DUMP_DIR=""; shift ;;
        *) selection="$1"; shift ;;
    esac
done

if [[ -z "$selection" ]]; then
    echo "Which task's test cases do you want to run?"
    echo "  1: Task-1"
    echo "  2: Task-2"
    echo "  3: Task-3"
    echo "  a: all tasks"
    echo "  q: quit"
    printf "> "
    if ! read -r selection; then
        echo ""
        echo "No input received." >&2
        exit 1
    fi
fi

selection=$(trim "$selection")

if [[ -z "$selection" ]]; then
    echo "No selection made." >&2
    exit 1
fi

case "$selection" in
    1|2|3)
        run_task "$selection"
        exit $?
        ;;
    a|A|all|ALL)
        overall=0
        results=()
        for task in 1 2 3; do
            if run_task "$task"; then
                results+=("Task-$task: PASS")
            else
                results+=("Task-$task: FAIL")
                overall=1
            fi
        done
        echo ""
        echo "=== Summary ==="
        printf '%s\n' "${results[@]}"
        exit $overall
        ;;
    q|Q|quit|QUIT)
        echo "Nothing to do."
        exit 0
        ;;
    *)
        echo "Invalid selection: '$selection' (expected 1, 2, 3, a or q)." >&2
        exit 1
        ;;
esac
