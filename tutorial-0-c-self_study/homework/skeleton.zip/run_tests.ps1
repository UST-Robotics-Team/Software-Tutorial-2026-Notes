param(
    [Alias("t")]
    [string]$Task,
    [Alias("n")]
    [switch]$NoDump,
    [Alias("b")]
    [switch]$Bonus
)

$ErrorActionPreference = 'Stop'
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir

if (-not (Get-Command gcc -ErrorAction SilentlyContinue)) {
    Write-Host "gcc was not found on PATH." -ForegroundColor Red
    exit 1
}

$tasks = @(
    @{ Number = 1; Folder = "Task-1"; Sources = @("main.c", "Task1.c") },
    @{ Number = 2; Folder = "Task-2"; Sources = @("main.c", "Task2.c") },
    @{ Number = 3; Folder = "Task-3"; Sources = @("main.c", "Task3.c", "given.c", "lib/dict.c") }
)

function Test-RuntimeDependent {
    param([int]$Number, [string]$Line)

    if ($Number -ne 3) { return $false }

    # Due to Task 3 using C rand(), some outputs differ between versions of libc. These outputs are ignored in grading.
    return (
        $Line -like "Unseen tiles for player:*" -or
        $Line -like "Current rack:*" -or
        $Line -like "Player [12] has * points of tiles left,*" -or
        $Line -match '^Player [12]: \d+ points$'
    )
}

function Invoke-TestProgram {
    param([string]$ExePath, [string]$InputPath, [string]$WorkingDir)
    $outFile = [System.IO.Path]::GetTempFileName()
    try {
        $previous = Get-Location
        try {
            Set-Location $WorkingDir
            cmd /c "`"$ExePath`" < `"$InputPath`" > `"$outFile`" 2>&1" | Out-Null
        }
        finally {
            Set-Location $previous
        }
        return [System.IO.File]::ReadAllText($outFile)
    }
    finally {
        Remove-Item -LiteralPath $outFile -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-TaskCase {
    param([int]$Number, [string]$DumpDir, [switch]$GradeBonus)

    $testsDir = "testcases"
    $taskDir = (Get-Location).Path
    $exePath = Join-Path $taskDir "Task$Number.exe"
    $passed = 0
    $failed = 0
    $skipped = 0
    $bonusSkipped = 0
    $dumped = 0

    $testCases = @(
        Get-ChildItem -Path $testsDir -Directory |
            Where-Object { $_.Name -match '^testcaseB?\d+$' } |
            Sort-Object @(
                @{ Expression = { if ($_.Name -match '^testcaseB') { 1 } else { 0 } } },
                @{ Expression = { [int]($_.Name -replace '^testcaseB?', '') } }
            )
    )

    if ($testCases.Count -eq 0) {
        Write-Host "No test cases found in $testsDir/" -ForegroundColor Red
        return $false
    }
    $dumpPath = $null
    if ($DumpDir) {
        $dumpPath = Join-Path $taskDir $DumpDir
        if (Test-Path $dumpPath) {
            Remove-Item -Path $dumpPath -Recurse -Force
        }
        New-Item -ItemType Directory -Path $dumpPath -Force | Out-Null
    }

    foreach ($testCase in $testCases) {
        $name = $testCase.Name
        if ($name -match '^testcaseB' -and -not $GradeBonus) {
            Write-Host "[SKIP] $name (bonus; pass -Bonus to grade)" -ForegroundColor DarkGray
            $bonusSkipped++
            continue
        }

        $inputFile = Join-Path $testCase.FullName "input.txt"
        $outputFile = Join-Path $testCase.FullName "output.txt"
        if (-not (Test-Path $inputFile) -or -not (Test-Path $outputFile)) {
            Write-Host "[SKIP] $name (missing input.txt or output.txt)" -ForegroundColor Yellow
            $skipped++
            continue
        }

        $actual = Invoke-TestProgram -ExePath $exePath -InputPath $inputFile -WorkingDir $taskDir

        if ($dumpPath) {
            [System.IO.File]::WriteAllText(
                (Join-Path $dumpPath ($name + ".txt")),
                $actual,
                (New-Object System.Text.UTF8Encoding($false))
            )
            $dumped++
        }

        $ok = $true
        $problems = @()

        foreach ($rawLine in (Get-Content $outputFile)) {
            $line = $rawLine.Trim()
            if ($line -eq "" -or $line.StartsWith("#")) { continue }
            if (Test-RuntimeDependent -Number $Number -Line $line) { continue }

            if ($line.StartsWith("!")) {
                $sub = $line.Substring(1).Trim()
                if ($sub -eq "") { continue }
                if ($actual.Contains($sub)) {
                    $ok = $false
                    $problems += "  must NOT contain: '$sub'"
                }
            }
            else {
                if (-not $actual.Contains($line)) {
                    $ok = $false
                    $problems += "  missing: '$line'"
                }
            }
        }

        if ($ok) {
            Write-Host "[PASS] $name" -ForegroundColor Green
            $passed++
        }
        else {
            Write-Host "[FAIL] $name" -ForegroundColor Red
            $problems | ForEach-Object { Write-Host $_ -ForegroundColor Red }
            $failed++
        }
    }

    Write-Host ""
    Write-Host "Passed: $passed   Failed: $failed   Skipped: $skipped"
    if ($bonusSkipped -gt 0) {
        Write-Host "Bonus skipped: $bonusSkipped (Part B; pass -Bonus to grade)" -ForegroundColor DarkGray
    }
    if ($dumped -gt 0) {
        Write-Host "Output dumped to $DumpDir/ ($dumped files)"
    }
    if ($passed -eq 0 -and $failed -eq 0) {
        Write-Host "No test cases were graded." -ForegroundColor Yellow
        return $false
    }
    return ($failed -eq 0)
}

function Invoke-TaskTests {
    param($TaskConfig)

    $number = $TaskConfig.Number
    $folder = $TaskConfig.Folder
    $sources = $TaskConfig.Sources

    Write-Host ""
    Write-Host "=== Task $number ($folder) ===" -ForegroundColor Cyan

    if (-not (Test-Path $folder -PathType Container)) {
        Write-Host "Missing task folder: $folder" -ForegroundColor Red
        return $false
    }

    Push-Location $folder
    $result = $false
    try {
        Write-Host "Building Task$number.exe ..."
        & gcc -Wuninitialized -std=c99 @sources -o Task$number -lm
        if ($LASTEXITCODE -ne 0) {
            Write-Host "Build failed for $folder" -ForegroundColor Red
        }
        else {
            $dumpDir = $null
            if (-not $NoDump) {
                $dumpDir = "dump"
            }
            $result = Invoke-TaskCase -Number $number -DumpDir $dumpDir -GradeBonus:$Bonus
        }
    }
    finally {
        Pop-Location
    }

    return $result
}

$selection = $Task

if ([string]::IsNullOrWhiteSpace($selection)) {
    Write-Host "Which task's test cases do you want to run?"
    Write-Host "  1: Task-1"
    Write-Host "  2: Task-2"
    Write-Host "  3: Task-3"
    Write-Host "  a: all tasks"
    Write-Host "  q: quit"
    Write-Host -NoNewline "> "
    $selection = (Read-Host)
    if ($null -eq $selection) { $selection = "" }
    $selection = $selection.Trim()
}

if ([string]::IsNullOrWhiteSpace($selection)) {
    Write-Host "No selection made." -ForegroundColor Red
    exit 1
}

switch -Regex ($selection) {
    '^[123]$' {
        $config = $tasks | Where-Object { $_.Number -eq [int]$selection }
        if (Invoke-TaskTests -TaskConfig $config) { exit 0 } else { exit 1 }
    }
    '^(a|all)$' {
        $overall = 0
        $results = @()
        foreach ($config in $tasks) {
            if (Invoke-TaskTests -TaskConfig $config) {
                $results += "Task-$($config.Number): PASS"
            }
            else {
                $results += "Task-$($config.Number): FAIL"
                $overall = 1
            }
        }
        Write-Host ""
        Write-Host "=== Summary ==="
        $results | ForEach-Object { Write-Host $_ }
        exit $overall
    }
    '^(q|quit)$' {
        Write-Host "Nothing to do."
        exit 0
    }
    default {
        Write-Host "Invalid selection: '$selection' (expected 1, 2, 3, a or q)." -ForegroundColor Red
        exit 1
    }
}
