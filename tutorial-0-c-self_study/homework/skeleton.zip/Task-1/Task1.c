//You are NOT ALLOWED to add any other libraries
//
#include "Task1.h"

#include <stdio.h>
#include <math.h>
//

//PART A (MANDATORY)
void rolling_average(double* data, int n, int window){
    //printf("Rolling average (window %d):\n", window);
    //printf("%-6s%-10s%s\n", "Index", "Reading", "Average");
    //printf("%-6d%-10.2f%.2f\n")
    //Task 1A(i)
}

//Task 1A(ii)

//Create the function kalman_init() here.

double kalman_step(Kalman* k, double measurement, double process_noise, double measurement_noise){
    //Task 1A(ii)
}

int convolve(Matrix* input, Matrix* kernel, Matrix* output){
    //Task 1A(iii)
}

//PART B (OPTIONAL)
int gaussian_filter(Matrix* input, Matrix* output, int window, double sigma){
    //Task 1B(i)
}

int median_filter(Matrix* input, Matrix* output, int window){
    //Task 1B
}
