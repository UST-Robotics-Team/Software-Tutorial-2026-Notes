//Provided helper functions for Task 2, please do not modify this file.
#ifndef TASK2_H
#define TASK2_H

//PART A (MANDATORY)
int password_check(char* password);
void email_check(char* email);

//PART B (OPTIONAL)
void regex(char** list, char* regex);

#endif